const icontype = [
  ['1']: {
    imgSize: [30, 19],
    src: "./static/img/配气站-30-19.png",
    scale:1,
  }
]

export { icontype }
