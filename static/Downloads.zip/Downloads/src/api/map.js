import request from '@/utils/request'
import $qs from 'qs'

// 普通登录
export function userLogin (data) {
  return request({
    url: '/login',
    method: 'post',
    data: $qs.stringify(data)
  })
}

// 获取Token
export function getAuth (data) {
  return request({
    url: '/webviewLogin',
    method: 'post',
    data: $qs.stringify(data)
  })
}

// 监测站点列表
export function stieList (data) {
  return request({
    url: '/screen/stie/list',
    method: 'GET',
    params: data
  })
}

// 重点监测项目列表
export function projectList (data) {
  return request({
    url: '/screen/project/list',
    method: 'GET',
    params: data
  })
}

// 项目详情
export function projectInfo (data) {
  return request({
    url: '/screen/project/info',
    method: 'GET',
    params: data
  })
}

// 基础信息列表
export function basicList (data) {
  return request({
    url: '/screen/basic/list',
    method: 'GET',
    params: $qs.stringify(data)
  })
}

// 温度热力图
export function heatMap (data) {
  return request({
    url: '/screen/heatMap',
    method: 'GET',
    params: data
  })
}
