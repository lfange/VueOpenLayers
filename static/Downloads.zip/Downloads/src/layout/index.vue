<template>
  <div class="map">
    <div id="container" />
  </div>
</template>
<script>
import 'ol/ol.css'
// import AMap from 'AMap'
import Map from 'ol/Map'
import View from 'ol/View'
import TileLayer from 'ol/layer/Tile'
import XYZ from 'ol/source/XYZ'
export default {
  data () {
    return {
      msg: 'hello World',
      maps: null,
      olMap: null
    }
  },
  mounted () {
    // this.gaodeInit()
    this.getOlInit()
  },
  methods: {
    getType () {
      // getStaion().then(res => {
      //   console.log('res', res)
      // })
    },
    gaodeInit: function () {
      // const _this = this
      // // 地图加载
      // _this.maps = new AMap.Map('container', {
      //   zoom: 8,
      //   center: [104.034809, 30.393538]
      // })
      // console.log('this', _this.maps)
    },
    getOlInit () {
      const baseLayer = [
        new TileLayer({
          source: new XYZ({
            // url: 'http://wprd0{1-4}.is.autonavi.com/appmaptile?x={x}&y={y}&z={z}&lang=zh_cn&size=1&scale=1&style=7'
            // url: 'http://webst0{1-4}.is.autonavi.com/appmaptile?style=6&x={x}&y={y}&z={z}'
            // url: 'http://cache1.arcgisonline.cn/arcgis/rest/services/ChinaOnlineCommunity/MapServer/tile/{z}/{y}/{x}'
            url: 'http://webrd01.is.autonavi.com/appmaptile?x={x}&y={y}&z={z}&lang=zh_cn&size=1&scale=1&style=8'
            // url: 'https://{a-c}.tile.openstreetmap.org/{z}/{x}/{y}.png'
          })
        })
      ]

      this.olMap = new Map({
        layers: baseLayer,
        target: 'container',
        view: new View({
          projection: 'EPSG:4326',
          center: [104.034809, 30.393538],
          zoom: 8,
          attributions: '中国共产党万岁'
        })
      })
    }
  }
}
</script>
<style scoped>
.map {
  width: 100%;
  height: 100%;
}
#container {
  width: 100%;
  height: 600px;
}
</style>
