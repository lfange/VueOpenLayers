import Vue from 'vue'
import Router from 'vue-router'
import layout from '@/layout/index'
import windlayer from '@/components/windlayer'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/layout',
      name: 'layout',
      component: layout
    },
    {
      path: '/windlayer',
      name: 'layout',
      component: windlayer
    },
    {
      path: '/ol6',
      name: 'layout',
      component: () => import('@/components/ol6')
    },
    {
      path: '/details',
      name: 'stationdetails',
      component: () => import('@/components/details')
    }
  ]
})
