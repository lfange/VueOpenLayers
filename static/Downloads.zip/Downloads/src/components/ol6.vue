<template>
  <div class="main">
    <div id="map" class="map" ></div>
    <div id="popup" class="ol-popup">
      <a href="#" id="popup-closer" class="ol-popup-closer"></a>
      <div id="popup-content"></div>
    </div>
    <!-- <button @click="waitData1">waitData1</button>
    <button @click="setPosition([102.917330, 30.106170])">定位</button>
    <button @click="getHot">getHot</button>
    <button @click="removse('1')">removse</button>
    <button @click="setZindex">setZindex</button>
    <button @click="romoveCulstLayer">romoveCulstLayer</button>
    <button @click="changeMapType('1')">changeMapType</button> -->
  </div>
</template>
<script>
import 'ol/ol.css'
import Overlay from 'ol/Overlay'
import { getAuth, userLogin } from '@/api/map'
import {toStringHDMS} from 'ol/coordinate'
import { toLonLat } from 'ol/proj'
import { initMap } from './map/initMap'
import { rendIcon } from './map/icon'
import { appEvent } from './map/appEvent'
import { getData } from './map/getData'
import cluster from './map/cluster'
import windLayer from './map/windLayer'
import area from './map/area'
export default {
  mixins: [ initMap, rendIcon, appEvent, getData, cluster, windLayer, area ],
  data () {
    return {
      res: null,
      loading: false,
      popupLayer: null // 弹出框样式
    }
  },
  created () {
    // this.userLogin()
    // this.login('Cookie', 'SESSION=121dd581-85f1-4833-b2e8-a9466bea7f7c')
  },
  mounted () {
    // this.StationList()
    // this.ProjectList()
    // this.BaseList()
  },
  methods: {
    login () {
      const FormData = {
        username: 'root',
        password: '123456',
        platform: 2 // 0:PC 1:IOS 2:android
      }
      userLogin(FormData).then(res => {
      })
    },
    popup () {
      let _this = this
      var container = document.getElementById('popup')
      var content = document.getElementById('popup-content')
      var closer = document.getElementById('popup-closer')
      _this.popupLayer = new Overlay({
        element: container,
        autoPan: true,
        autoPanAnimation: {
          duration: 250
        }
      })
      closer.onclick = function () {
        // _this.popupLayer.setPosition(undefined)
        // closer.blur()
        return false
      }
      _this.map.addOverlay(_this.popupLayer)
      // display popup on click
      _this.map.on('singleclick', function (evt) {
        var coordinate = evt.coordinate
        var hdms = toStringHDMS(toLonLat(coordinate))
        console.log('coordinate', evt)
        content.innerHTML = '<p>You clicked here:</p><code>' + hdms + '</code>'
        var feature = _this.map.forEachFeatureAtPixel(evt.pixel,
          function (feature) {
            return feature
          })
        // 移出点击位置的图标
        if (_this.clickLayer) _this.map.removeLayer(_this.clickLayer)
        if (feature) {
          // 聚合数据结构变化
          console.log('feature.values_', feature.values_)
          if (feature.values_.features) {
            _this.setPosition(coordinate)
            _this.typeListen(feature.values_.features[0].values_)
          } else {
            // 点击feature的类型
            const featureType = feature.getGeometry().getType()
            // 线没有聚合，属于项目
            if (featureType === 'LineString') {
              _this.typeListen(feature.values_)
            } else {
              _this.weatherQuery(coordinate)
            }
          }
          // var coordinates = feature.getGeometry().getCoordinates()
          // _this.popupLayer.setPosition(coordinates)
        } else {
          _this.locationIcon(coordinate)
          _this.weatherQuery(coordinate)
        }
      })
    },
    // 点击事件分类，触发给app传参
    typeListen (data) {
      if (data.typeId) {
        console.log('站点数据')
        this.StationClick(data)
      } else if (data.basicId) {
        console.log('基础数据')
        this.baseClick(data)
      } else if (data.projectId) {
        console.log('点击')
        this.ProjectClick(data)
      }
    },
    getCookie (name) {
      // 获取当前所有cookie
      var strCookies = document.cookie
      // 截取变成cookie数组
      var array = strCookies.split(';')
      // 循环每个cookie
      for (var i = 0; i < array.length; i++) {
        // 将cookie截取成两部分
        var item = array[i].split('=')
        // 判断cookie的name 是否相等
        if (item[0] === name) {
          return item[1]
        }
      }
      return null
    },
    // 登录
    userLogin () {
    //   const FormData = {
    //     username: 'root',
    //     password: '123456',
    //     platform: 2 // 0:PC 1:IOS 2:android
    //   }
    //   userLogin(FormData).then(res => {
    //   })
      getAuth({'token': this.getCookie('cookie') || '759d886a-577a-4427-ab15-d9f5f5eb263d'}).then(res => {
        console.log('resssss', res)
        this.ProjectList()
        this.res = res
      })
    }
  }
}
</script>
<style>
  .map {
    width: 100%;
    height: 100vh;
  }
  /* img {
    filter: grayscale(100%)!important;
    -webkit-filter: grayscale(100%)!important;
  } */
  .main {
    position: relative;
  }
  .loading {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.2);
  }
  .loading p {
    width: 100px;
    margin: 50% auto 0;
  }
  .ol-popup {
    position: absolute;
    background-color: white;
    box-shadow: 0 1px 4px rgba(0,0,0,0.2);
    padding: 15px;
    border-radius: 10px;
    border: 1px solid #cccccc;
    bottom: 12px;
    left: -50px;
    min-width: 280px;
  }
  .ol-popup:after, .ol-popup:before {
    top: 100%;
    border: solid transparent;
    content: " ";
    height: 0;
    width: 0;
    position: absolute;
    pointer-events: none;
  }
  .ol-popup:after {
    border-top-color: white;
    border-width: 10px;
    left: 48px;
    margin-left: -10px;
  }
  .ol-popup:before {
    border-top-color: #cccccc;
    border-width: 11px;
    left: 48px;
    margin-left: -11px;
  }
  .ol-popup-closer {
    text-decoration: none;
    position: absolute;
    top: 2px;
    right: 8px;
  }
  .ol-popup-closer:after {
    content: "✖";
  }
  .ol-zoom {
    /*隐藏地图左上角的+-号*/
    display: none;
  }
</style>
