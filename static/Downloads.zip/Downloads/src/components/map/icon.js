
import Feature from 'ol/Feature'
import {Vector as VectorLayer} from 'ol/layer'
import GeoJSON from 'ol/format/GeoJSON'
import VectorSource from 'ol/source/Vector'
import Point from 'ol/geom/Point'
import { Style, Icon, Stroke, Text, Fill } from 'ol/style'
// import $qs from 'qs'

const iconOpArray = {
  projectType: [], // 重点监测项目列表的额数据
  typeId: [], // 监测站点梳理列表
  type: [],
  factorType: [], // 站点不同类型
  monitor: [], // 视频监控
  xianqing: []
}
iconOpArray.typeId[1] = require('../../../static/images/mipmap-xhdpi/qxz.png')
iconOpArray.typeId[2] = require('../../../static/images/mipmap-xhdpi/shuifen.png')
iconOpArray.typeId[3] = require('../../../static/images/mipmap-xhdpi/dizhi.png')
iconOpArray.typeId[4] = require('../../../static/images/mipmap-xhdpi/shipin.png')
iconOpArray.type[1] = require('../../../static/images/mipmap-xhdpi/yiyuan.png')
iconOpArray.type[2] = require('../../../static/images/mipmap-xhdpi/yjbl.png')
iconOpArray.type[3] = require('../../../static/images/mipmap-xhdpi/renyuan2.png')
iconOpArray.type[4] = require('../../../static/images/mipmap-xhdpi/paichusuo.png')
iconOpArray.projectType[1] = require('../../../static/images/mipmap-xhdpi/daolu.png')
iconOpArray.projectType[2] = require('../../../static/images/mipmap-xhdpi/shuiku.png')
iconOpArray.projectType[3] = require('../../../static/images/mipmap-xhdpi/shanchen.png')
iconOpArray.projectType[4] = require('../../../static/images/mipmap-xhdpi/jingdian.png')
iconOpArray.factorType[0] = '/static/images/mipmap-xhdpi/wendu.png'
iconOpArray.factorType[1] = '/static/images/mipmap-xhdpi/shui.png'
iconOpArray.factorType[2] = '/static/images/mipmap-xhdpi/fengzhan.png'
iconOpArray.factorType[3] = '/static/images/mipmap-xhdpi/shandian.png'
iconOpArray.factorType[4] = '/static/images/mipmap-xhdpi/qiang.png'
iconOpArray.monitor = '/static/images/mipmap-xhdpi/shipin.png'
iconOpArray.xianqing = '/static/images/mipmap-xhdpi/xianqing.png'

const rendIcon = {
  data () {
    return {
      IconLayer: null,
      iconFeatures: [],
      positionLayer: [],
      userImg: 'http://weather.kedalo.com:9989/screen/headImage?headImg=user/4c2548f7-333e-41ee-9229-71db7c6b8cd0.png',
      factorType: 0,
      clusterVetSource: null,
      isRealStation: true,
      clickLayer: null
    }
  },
  methods: {
    styleFunction (feature) {
      const type = feature.getGeometry().getType()
      const data = feature.values_
      let style
      var isWeaStation = feature.values_.typeId
      if (type === 'Point') { // 站点
        if (isWeaStation && isWeaStation === 1 && this.isRealStation) {
          style = new Style({
            geometry: feature.getGeometry(),
            image: new Icon({
              src: data.src,
              scale: 0.4
            }),
            text: new Text({
              text: data.text,
              offsetX: 6,
              scale: 0.9,
              fill: new Fill({
                color: 'white'
              })
            })
          })
        } else {
          style = new Style({
            geometry: feature.getGeometry(),
            image: new Icon({
              src: data.src
            })
          })
        }
      } else if (type === 'LineString') { // 项目道路
        style = new Style({
          stroke: new Stroke({
            color: 'rgb(140,196,252)',
            width: 6
          }),
          text: new Text({
            text: data.projectName,
            offsetX: 3,
            fill: new Fill({
              color: '#409EFF'
            })
          })
        })
      }
      return style
    },
    // 组装为地图需要的数据
    IconInit (data) {
      let _this = this
      // 聚合组装数据
      const clusterGeojson = {
        type: 'FeatureCollection',
        crs: {
          type: 'Feature'
        },
        features: []
      }
      const geojsonObject = {
        type: 'FeatureCollection',
        crs: {
          type: 'Feature'
        },
        features: []
      }
      data.map(icon => {
        let type = icon.type ? 'type' : (icon.typeId ? 'typeId' : (icon.projectType ? 'projectType' : (icon.monitorId ? 'monitorId' : (icon.xianqing ? 'xianqing' : ''))))
        // 动态添加地图需要的数据对象
        const iconType = icon.projectType || icon.typeId || icon.type
        icon.src = iconType ? iconOpArray[type][iconType] : iconOpArray.monitor
        const center = type === 'projectType' ? this.isIconFeature(icon) : [icon.lng, icon.lat]
        const isPoint = typeof center[0] === 'number' ? 'Point' : 'LineString'
        let obj = {
          type: 'Feature',
          properties: icon,
          geometry: {
            type: isPoint,
            coordinates: center
          }
        }
        if (this.isRealStation) {
          const factorType = _this.factorType
          // bc 温度 ba 雨量 af 风速 aa 风向
          var text = factorType === 0 ? icon.bc : (factorType === 1 ? icon.ba : (factorType === 2 ? icon.af : ''))
          if (!text) return
          if (icon.bc && factorType === 0) text = icon.bc + '℃'
          if (icon.ba && factorType === 1) text = icon.ba + 'mm'
          if ((icon.aa || icon.af) && factorType === 2) text = icon.af + 'm/s'
          console.log('icon.', icon, iconType)
          console.log('text', text)
          icon.text = text
          icon.src = iconOpArray.factorType[factorType]
          if (isPoint === 'Point') {
            clusterGeojson.features.push(obj)
          } else {
            geojsonObject.features.push(obj)
          }
        } else {
          if (isPoint === 'Point') {
            clusterGeojson.features.push(obj)
          } else {
            geojsonObject.features.push(obj)
          }
        }
      })
      // 聚合数据源
      _this.clusterVetSource = new VectorSource({
        features: (new GeoJSON()).readFeatures(clusterGeojson)
      })
      // 没有聚合的数据源
      let nomalSource = new VectorSource({
        features: (new GeoJSON()).readFeatures(geojsonObject)
      })
      // console.log('_this.iconFeatures', _this.iconFeatures)
      _this.IconLayer = new VectorLayer({
        source: nomalSource,
        style: _this.styleFunction
      })
      _this.map.addLayer(_this.IconLayer)
      console.log('clusterGeojson', clusterGeojson)
      // 开启聚合
      this.initCluter()
      this.setZindex()
      if (data[0].lng) {
        this.view.animate({center: [data[0].lng, data[0].lat], zoom: 9, duration: 1500})
      } else {
        this.view.animate({center: this.isIconFeature(data[0]), zoom: 9, duration: 1500})
      }
      this.loading = false
    },
    // 监测项目判断是点还是线
    isIconFeature (icon) {
      if (!icon.loc) return false
      let arr = icon.loc.slice(2, -2).split(',')
      arr.map((it, index) => {
        if (it.indexOf('{') > -1) {
          arr[index] = it.replace(/\{/g, '')
          it = it.substring(it.indexOf('{'))
        } else if (it.indexOf('}') > -1) {
          arr[index] = it.replace(/\}/g, '')
        }
      })
      let changeArr = []
      arr.forEach((element, index) => {
        if (arr.length > 2) {
          if (index % 2 === 0) {
            changeArr.push([Number(arr[index + 1]), Number(arr[index])])
            // changeArr[index] = arr[index + 1]
            // changeArr[index + 1] = arr[index]
          }
        } else {
          if (index % 2 === 0) {
            changeArr[index] = Number(arr[index + 1])
            changeArr[index + 1] = Number(arr[index])
          }
        }
      })
      return changeArr
    },
    // 画线
    LineFeature (center, incon) {
      var lineFeature = new Feature({
        geometry: new Point(center)
      })
      let lineStyle = new Style({
        stroke: new Stroke({
          color: 'green',
          width: 1
        })
      })
      lineFeature.setStyle(lineStyle)
      this.iconFeatures.push(lineFeature)
    },
    romveIconLayer () {
      let _this = this
      _this.map.removeLayer(_this.IconLayer)
      _this.IconLayer = null
    },
    // 位置图标显示
    positionIcon (center) {
      let _this = this
      var iconFeature = new Feature({
        geometry: new Point(center),
        name: '当前位置',
        population: 4000,
        rainfall: 500
      })
      var iconStyle = new Style({
        image: new Icon({
          scale: 0.2,
          src: _this.userImg
        })
      })
      iconFeature.setStyle(iconStyle)
      var vectorSource = new VectorSource({
        features: [iconFeature]
      })
      this.positionLayer = new VectorLayer({
        source: vectorSource
      })
      this.map.addLayer(this.positionLayer)
    },
    // 设置点击位置的图标
    locationIcon (location) {
      var iconFeature = new Feature({
        geometry: new Point(location),
        name: '点击位置',
        population: 4000,
        rainfall: 500
      })
      var iconStyle = new Style({
        image: new Icon({
          src: '/static/images/setIcon.png'
        })
      })
      iconFeature.setStyle(iconStyle)
      var vectorSource = new VectorSource({
        features: [iconFeature]
      })
      this.clickLayer = new VectorLayer({
        source: vectorSource
      })
      this.map.addLayer(this.clickLayer)
    }
  }
}

export { rendIcon }
