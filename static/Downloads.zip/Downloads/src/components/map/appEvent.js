export const appEvent = {
  data () {
    return {
      positionFirst: true
    }
  },
  mounted () {
    // 注册事件
    this.showMyLocation()
    this.showProjectList()
    this.showStationList()
    this.RealTimeStation()
    this.showBaseList()
    this.mapType()
    this.weatherType()
    this.getfactor()
    this.projectDetails()
    this.forceWeather()
    window.onload = () => {
      this.InitDone()
    }
  },
  methods: {
    // js调用app ==================================
    markClick (data) {
      this.$bridge.callHandler('onProjectMarkClick', {'param': '还有个方法'}, (res) => {
        this.test = res
      })
    },
    // 站点点击事件
    StationClick (data) {
      const param = JSON.stringify(data)
      this.$bridge.callHandler('onStationMarkClick', param, (res) => {
        this.test = res
      })
    },
    // 基础数据点击事件
    baseClick (data) {
      const param = JSON.stringify(data)
      this.$bridge.callHandler('onBaseMarkClick', param, (res) => {
        this.test = res
      })
    },
    // 项目点击事件
    ProjectClick (data) {
      const param = JSON.stringify(data)
      this.$bridge.callHandler('onProjectMarkClick', param, (res) => {
        this.test = res
      })
    },
    // 点击查询天气
    weatherQuery (data) {
      const param = JSON.stringify({lng: data[0], lat: data[1]})
      this.$bridge.callHandler('onMapPosClick', param, (res) => {
        this.test = res
      })
    },
    // 地图加载完成获取位置信息
    InitDone () {
      this.$bridge.callHandler('mapInitDone', {'param': 'mapInitDone'}, datas => {
        console.log('datas', datas)
      })
    },
    // 站点点击
    stationClick (data) {
      console.log('data', data.loc, this.isIconFeature(data))
      const param = JSON.stringify(data)
      this.$bridge.callHandler('onStationMarkClick', param, (res) => {
      })
    },
    // 点击视频监控
    monitonClick (data) {
      console.log('monit', data)
      const param = JSON.stringify(data)
      this.$bridge.callHandler('onMonitorMarkClick', param, (res) => {
      })
    },
    // app调js =====================================
    // 展示当前用户位置
    showMyLocation () {
      let _this = this
      this.$bridge.registerHandler('showMyLocation', (datas, responseCallback) => {
        const data = JSON.parse(datas)
        // alert('showMyLocation' + datas)
        this.userImg = 'data:image/png;base64,' + data.avatar
        let arr = [data.lng, data.lat]
        // 第一次不使用app传来的得位置定位
        if (_this.positionFirst) {
        } else {
          _this.positionIcon(arr)
          _this.setPosition(arr)
          _this.positionFirst = false
        }
      })
    },
    // 实时监测站点
    RealTimeStation () {
      this.$bridge.registerHandler('showRealTimeStationList', (datas, responseCallback) => {
        const data = JSON.parse(datas)
        // alert('showRealTimeStationList' + datas)
        this.factorType = data.factorType
        if (data.stationList && data.stationList.length > 0) {
          this.appGetParams.station = JSON.stringify(data.stationList)
          this.isRealStation = true // 区分实况数据还是普通数据
          this.waitData()
        } else {
          this.appGetParams.station = null
        }
      })
    },
    // 监测站点列表
    showStationList () {
      this.$bridge.registerHandler('showStationList', (datas, responseCallback) => {
        const data = JSON.parse(datas)
        // alert('showStationList' + datas)
        this.appisCall++
        this.factorType = data.factorType
        if (data.stationList && data.stationList.length > 0) {
          this.appGetParams.station = JSON.stringify(data.stationList)
        } else {
          this.appGetParams.station = null
        }
      })
    },
    // 监测项目列表
    showProjectList () {
      this.$bridge.registerHandler('showProjectList', (datas, responseCallback) => {
        // alert('showProjectList:' + datas)
        const data = JSON.parse(datas)
        this.appisCall++
        if (data && data.length > 0) {
          // this.StationList(datas)
          this.appGetParams.projectList = datas
        } else {
          this.appGetParams.projectList = null
        }
      })
    },
    // 基础数据列表
    showBaseList () {
      this.$bridge.registerHandler('showBaseList', (datas, responseCallback) => {
        // alert('showBaseList' + datas)
        const data = JSON.parse(datas)
        this.appisCall++
        if (data && data.length > 0) {
          // this.StationList(datas)
          this.appGetParams.baseList = datas
        } else {
          this.appGetParams.baseList = null
        }
      })
    },
    // 获取站点类型
    getfactor () {
      this.$bridge.registerHandler('refreshFactorType', (datas, responseCallback) => {
        // fatorType  0 气温 1 降水 2 风场 3强降雨天气
        // alert('refreshFactorType' + JSON.parse(datas))
        this.factorType = JSON.parse(datas)
        // this.waitData()
      })
    },
    // 设置卫星模式还是普通模式
    mapType () {
      let _this = this
      this.$bridge.registerHandler('changeMapType', (datas, responseCallback) => {
        // 0 普通地图， 1 卫星地图
        this.mapStyle = datas
        _this.changeMapType(datas)
      })
    },
    // 设置实况数据
    weatherType () {
      this.$bridge.registerHandler('refreshWeatherType', (datas, responseCallback) => {
        // alert('weatherType' + datas)
      })
    },
    // 强制刷新天气
    forceWeather () {
      this.$bridge.registerHandler('refreshForecastWeather', (datas, responseCallback) => {
        const data = JSON.parse(datas)
        // alert('refreshForecastWeather' + datas)
        if (data.data && data.data.length === 0) return
        this.res = data.data
        this.test = JSON.parse(data.data)
        this.$nextTick(() => {
          this.addSource(JSON.parse(data.data))
        })
      })
    },
    // 项目详情获取项目
    projectDetails () {
      this.$bridge.registerHandler('setProjectDetail', (datas, responseCallback) => {
        const data = JSON.parse(datas)
        this.isRealStation = false
        // alert('setProjectDetail' + datas)
        this.renderProject(data)
      })
    }
  }
}
