import GeoJSON from 'ol/format/GeoJSON'
import { Vector as VectorLayer } from 'ol/layer'
import { Vector as VectorSource } from 'ol/source.js'
import { areaStyle } from '@/utils/Linestyle.js'

const area = {
  data () {
    return {
      areaLayer: null
    }
  },
  mounted () {

  },
  methods: {
    initAreaLayer () {
      // this.setZindex()
      // fatorType  0 气温 1 降水 2 风场 3强降雨天气
      const area = require('../../../static/json/yaan.json')
      // 显示数据源
      var fees = new GeoJSON().readFeaturesFromObject(area)
      let areaSource = new VectorSource({
        features: fees
      })
      this.areaLayer = new VectorLayer({
        source: areaSource,
        style: areaStyle
      })
      this.areaLayer.setZIndex(2)
      //  获取这个图层上面加的点线信息 this.pielayer.getSource().getFeatures()
      this.map.addLayer(this.areaLayer)
    }
  }
}
export default area
