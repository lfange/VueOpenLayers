import Map from 'ol/Map'
import View from 'ol/View'
import { heatMap } from '@/api/map'
import { Tile as TileLayer } from 'ol/layer'
import {getWidth, getTopLeft} from 'ol/extent'
import {get as getProjection} from 'ol/proj'
import TileWMS from 'ol/source/TileWMS'
// import OSM from 'ol/source/OSM.js'
// import XYZ from 'ol/source/XYZ'
import WMTS from 'ol/source/WMTS'
import WMTSTileGrid from 'ol/tilegrid/WMTS'
import {defaults as defaultInteractions, Select} from 'ol/interaction'
export const initMap = {
  data () {
    return {
      map: null,
      baseLayer: null,
      satelayer: null,
      // url: 'http://wprd0{1-4}.is.autonavi.com/appmaptile?x={x}&y={y}&z={z}&lang=zh_cn&size=1&scale=1&style=7',
      // url: 'http://webst0{1-4}.is.autonavi.com/appmaptile?style=6&x={x}&y={y}&z={z}',
      // url: 'http://cache1.arcgisonline.cn/arcgis/rest/services/ChinaOnlineCommunity/MapServer/tile/{z}/{y}/{x}',
      // url: 'http://webrd01.is.autonavi.com/appmaptile?x={x}&y={y}&z={z}&lang=zh_cn&size=1&scale=1&style=8',
      // url: 'https://{a-c}.tile.openstreetmap.org/{z}/{x}/{y}.png',
      // url: 'https://webrd01.is.autonavi.com/appmaptile?lang=zh_cn&size=1&scale=1&style=8&x={x}&y={y}&z={z}',
      sateurl: '"http://{a-c}.sm.mapstack.stamen.com/" + "(toner-lite,$fff[difference],$fff[@23],$fff[hsl-saturation@20])/" + "{z}/{x}/{y}.png',
      // url: 'http://map.geoq.cn/ArcGIS/rest/services/ChinaOnlineStreetPurplishBlue/MapServer/tile/{z}/{y}/{x}',
      // url: 'http://webrd01.is.autonavi.com/appmaptile?x={x}&y={y}&z={z}&lang=zh_cn&size=1&scale=1&style=7',
      // url: 'https://b.tile.openstreetmap.org/{x}/{y/{z}.png',
      // url: 'http://mt2.google.cn/vt/lyrs=m@167000000&hl=zh-CN&gl=cn&x=420&y=193&z=9&s=Galil',
      url: 'http://map.kedalo.com:8080/geoserver/chinaosm/wms',
      // 地图View展示选项配置
      viewOptions: {
        projection: 'EPSG:4326',
        // center: [102.87855327334883, 29.95539168988012], // [104.089175, 30.650451]
        center: [102.90150703541086, 29.98040667814843], // [104.089175, 30.650451]
        zoom: 10,
        extent: [100.65931204699675, 26.878467612358467, 104.12786186377534, 31.210931187242686], // [minX, minY, maxX, maxY]
        minZoom: 7,
        maxZoom: 15
      },
      view: null,
      source: null,
      mapStyle: '0',
      pielayer: null // 点线信息的图层
    }
  },
  mounted () {
    this.initMapType()
    this.initMap()
  },
  methods: {
    initMapType () {
      let _this = this
      var projection = getProjection('EPSG:4326')
      var projectionExtent = projection.getExtent()
      var size = getWidth(projectionExtent) / 256
      var resolutions = new Array(14)
      var matrixIds = new Array(14)
      for (var z = 0; z < 14; ++z) {
        // generate resolutions and matrixIds arrays for this WMTS
        resolutions[z] = size / Math.pow(2, z)
        matrixIds[z] = z
      }
      // 普通地图底图
      _this.baseLayer = new TileLayer({
        source: new TileWMS({
          url: _this.url,
          params: {
            'FORMAT': 'image/png',
            'VERSION': '1.1.1',
            tiled: true,
            'LAYERS': 'chinaosm:osm',
            'exceptions': 'application/vnd.ogc.se_inimage',
            tilesOrigin: 8153786 + ',' + 1779502.5},
          serverType: 'geoserver',
          crossOrigin: 'anonymous'
        })
      })

      // // 卫星地图底图
      // this.satelayer = new TileLayer({
      //   source: new XYZ({
      //     url: _this.sateurl
      //   })
      // })

      this.satelayer = new TileLayer({
        source: new WMTS({
          attributions: '',
          url: 'http://t{0-6}.tianditu.com/img_c/wmts?tk=405a9c7a0f92da453ee4162bbc64e008',
          // url: 'http://map.kedalo.com:8080/geoserver/gwc/chinaosm/wmts',
          layer: 'img',
          matrixSet: 'c',
          format: 'tiles',
          projection: projection,
          tileGrid: new WMTSTileGrid({
            origin: getTopLeft(projectionExtent),
            resolutions: resolutions,
            matrixIds: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20]
          }),
          style: 'default',
          wrapX: true
        })
      })

      var wmsSource = new WMTS({
        attributions: '',
        url: 'http://map.kedalo.com:8080/geoserver/gwc/chinaosm/wmts',
        layer: '0',
        matrixSet: 'EPSG:4326',
        format: 'image/png',
        projection: projection,
        tileGrid: new WMTSTileGrid({
          origin: getTopLeft(projectionExtent),
          resolutions: resolutions,
          matrixIds: matrixIds
        }),
        style: 'default',
        wrapX: true
      })
      var wmsLayer = new TileLayer({
        source: wmsSource
      })
      console.log('wmsLayer', wmsLayer)
    },
    // 加载地图底图
    initMap () {
      let _this = this
      _this.view = new View(_this.viewOptions)
      this.map = new Map({
        // 移动端禁止地图旋转  pinchRotate
        interactions: defaultInteractions({ pinchRotate: false }).extend([new Select({
          condition: function (evt) {
            return evt.type === 'pointermove' || evt.type === 'singleclick'
          },
          style: _this.selectStyleFunction // 设置聚合状态选中样式
        })]),
        layers: [ _this.baseLayer ],
        target: 'map',
        view: _this.view
      })
      // this.addSource()
      this.popup()
      this.initAreaLayer()
      // this.initWind() // 风场加载
    },
    // 定位
    setPosition (center) {
      console.log('getZoom', this.view.getZoom())
      let zoom = this.view.getZoom()
      if (this.view.getZoom() < 12) {
        zoom = 11
      }
      this.view.animate({
        center: center,
        zoom: zoom,
        duration: 1500
      })
    },
    // 设置天气模式
    changeMapType () {
      if (this.mapStyle === '0') {
        this.map.removeLayer(this.satelayer)
        this.map.addLayer(this.baseLayer)
      } else if (this.mapStyle === '1') {
        this.map.removeLayer(this.baseLayer)
        this.map.addLayer(this.satelayer)
      }
    },
    // 设置层级
    setZindex () {
      if (this.clustLayer) this.clustLayer.setZIndex(3)
      console.log('this.IconLayer', this.IconLayer)
      if (this.IconLayer) this.IconLayer.setZIndex(3)
    },
    getHot () {
      let params = {
        time: 1589529600000,
        // time: Date.parse(new Date()),
        type: 3
      }
      console.log('params', params)
      heatMap(params).then(res => {
        let arr = JSON.parse(res.data.data)
        // const datss = require('../../../static/json/data.json')
        // this.addSource(datss)
        this.initWind(arr)
      })
    }
  }
}
