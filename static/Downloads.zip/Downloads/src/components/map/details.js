
import Feature from 'ol/Feature'
import {Vector as VectorLayer} from 'ol/layer'
import VectorSource from 'ol/source/Vector'
import Point from 'ol/geom/Point'
import { Style, Icon, Stroke } from 'ol/style'
import LineString from 'ol/geom/LineString'
// import Polygon from 'ol/geom/Polygon'

const details = {
  data () {
    return {
      projectSource: [],
      circleLayer: null
    }
  },
  methods: {
    // pc端测试
    pcProject () {
      this.ProjectList().then(res => {
        this.fanwei(this.isIconFeature(res[1]))
        const data = this.projectSource
        let source = []
        if (data.monitor.length !== 0) {
          source.push(...data.monitor)
        }
        if (data.sites.length !== 0) {
          source.push(...data.sites)
        }
        if (data) this.IconInit(source)
      })
    },
    // 处理数据
    renderProject (res) {
      this.fanwei(this.isIconFeature(res))
      const data = res.entity
      let source = []
      if (data.monitor.length !== 0) {
        source.push(...data.monitor)
      }
      if (data.sites.length !== 0) {
        source.push(...data.sites)
      }
      if (data) this.IconInit(source)
    },
    // 详情页面将之前的坐标标记出来
    fanwei (center) {
      if (this.circleLayer) this.map.removeLayer(this.circleLayer)
      var circleFeature, iconStyle
      const isPoint = typeof center[0] === 'number' ? 'Point' : 'LineString'
      if (isPoint === 'Point') {
        circleFeature = new Feature({
          geometry: new Point(center),
          name: 'warning',
          population: 4000,
          rainfall: 500
        })
        iconStyle = new Style({
          image: new Icon({
            scale: 1.5,
            src: '/static/images/mipmap-xhdpi/xianqing.png'
          })
        })
      } else if (isPoint === 'LineString') {
        circleFeature = new Feature({
          geometry: new LineString(center),
          population: 4000,
          rainfall: 500
        })
        iconStyle = new Style({
          stroke: new Stroke({
            color: 'rgb(140,196,252)',
            width: 6
          })
        })
      }
      circleFeature.setStyle(iconStyle)
      var vectorSource = new VectorSource({
        features: [circleFeature]
      })
      this.circleLayer = new VectorLayer({
        source: vectorSource
      })
      this.map.addLayer(this.circleLayer)
    }
  }
}

export default details
