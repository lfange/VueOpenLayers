import GeoJSON from 'ol/format/GeoJSON'
import { Vector as VectorLayer } from 'ol/layer'
import { Vector as VectorSource } from 'ol/source.js'
import { TempeStyle, rainStyle } from '@/utils/Linestyle.js'
import { WindLayer } from 'ol-wind'

const windLayer = {
  data () {
    return {
      windLay: null,
      test: null
    }
  },
  mounted () {
  },
  methods: {
    // 风场加载
    initWind (data) {
      let _this = this
      console.log('initWind', data)
      // const ress = require('../../../static/json/2020050618.json')
      const ress = require('../../../static/json/weather.json')
      console.log('ress', ress)
      if (_this.windLay) this.map.removeLayer(_this.windLay)
      // if (!data) return
      _this.windLay = new WindLayer(ress, {
        forceRender: false,
        windOptions: {
          // colorScale: scale,
          globalAlpha: 0.8,
          velocityScale: 1 / 200,
          paths: 5000,
          width: 3, // 线的宽度
          // eslint-disable-next-line no-unused-vars
          colorScale: [
            'rgb(36,104, 180)',
            'rgb(60,157, 194)',
            'rgb(128,205,193 )',
            'rgb(151,218,168 )',
            'rgb(198,231,181)',
            'rgb(238,247,217)',
            'rgb(255,238,159)',
            'rgb(252,217,125)',
            'rgb(255,182,100)',
            'rgb(252,150,75)',
            'rgb(250,112,52)',
            'rgb(245,64,32)',
            'rgb(237,45,28)',
            'rgb(220,24,32)',
            'rgb(180,0,35)'
          ],
          // colorScale: scale,
          generateParticleOption: false
        },
        // map: _this.map,
        projection: 'EPSG:4326'
      })
      this.map.addLayer(_this.windLay)
    },
    // 加载要展示的风云等数据层
    addSource (dats) {
      // this.setZindex()
      // fatorType  0 气温 1 降水 2 风场 3强降雨天气
      let _this = this
      if (this.clustLayer) this.map.removeLayer(this.clustLayer)
      if (this.IconLayer) this.map.removeLayer(this.IconLayer)

      if (this.pielayer) this.map.removeLayer(this.pielayer)
      if (this.factorType === 2 || this.factorType === 3) return // this.initWind(dats)
      const styleFuntion = this.factorType === 0 ? TempeStyle : rainStyle
      // 显示数据源
      var fees = new GeoJSON().readFeaturesFromObject(dats)
      this.source = new VectorSource({
        features: fees
      })
      var vector = new VectorLayer({
        source: _this.source,
        style: styleFuntion,
        opacity: 0.4
      })
      //  获取这个图层上面加的点线信息 this.pielayer.getSource().getFeatures()
      _this.pielayer = vector
      this.map.addLayer(_this.pielayer)
    },
    removse () {
      console.log('this.windLay', this.windLay, this.windLay.getData())
      console.log('d', document.getElementsByTagName('canvas'))
      let parent = document.getElementsByClassName('ol-layers')[0]
      console.log('parent', parent)
      parent.removeChild(parent.children[1])
      this.windLay = null
      this.map.removeLayer(this.windLay)
    }
  }
}
export default windLayer
