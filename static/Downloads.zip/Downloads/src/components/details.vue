<template>
  <div class="main">
    <div id="map" class="map" ></div>
    <div id="popup" class="ol-popup">
      <a href="#" id="popup-closer" class="ol-popup-closer"></a>
      <div id="popup-content"></div>
    </div>
    <!-- <button @click="waitData1">waitData1</button>
    <button @click="setPosition([102.917330, 30.106170])">定位</button>
    <button @click="fanwei([[102.917330, 30.106170], [101.546578, 29.5656]])">[102.917330, 30.106170]</button>
    <button @click="getSouce">getSouce</button>
    <button @click="pcProject">pcProject</button>
    <button @click="getHot">getHot</button> -->
  </div>
</template>
<script>
import 'ol/ol.css'
import Overlay from 'ol/Overlay'
import { projectInfo } from '@/api/map'
import { initMap } from './map/initMap'
import { rendIcon } from './map/icon'
import { appEvent } from './map/appEvent'
import { getData } from './map/getData'
import details from '@/components/map/details'
import cluster from '@/components/map/cluster'
import windLayer from '@/components/map/windLayer'
export default {
  mixins: [ initMap, rendIcon, appEvent, getData, cluster, windLayer, details ],
  data () {
    return {
      res: null,
      loading: false,
      popupLayer: null // 弹出框样式
    }
  },
  created () {
  },
  methods: {
    popup () {
      let _this = this
      var container = document.getElementById('popup')
      var content = document.getElementById('popup-content')
      var closer = document.getElementById('popup-closer')
      _this.popupLayer = new Overlay({
        element: container,
        autoPan: true,
        autoPanAnimation: {
          duration: 250
        }
      })
      closer.onclick = function () {
        _this.popupLayer.setPosition(undefined)
        closer.blur()
        return false
      }
      _this.map.addOverlay(_this.popupLayer)
      // display popup on click
      _this.map.on('singleclick', function (evt) {
        var coordinate = evt.coordinate
        console.log('evt.coordinate', evt)
        var feature = _this.map.forEachFeatureAtPixel(evt.pixel,
          function (feature) {
            return feature
          })
        if (feature) {
          _this.res = feature.values_
          // 聚合数据结构变化
          if (feature.values_.features) {
            const data = feature.values_.features[0].values_
            _this.setPosition(coordinate)
            _this.typeListen(data)
            // 弹框内容
            let title = data.deviceName || data.monitorName
            let cont = data.remarks || 'test'
            content.innerHTML = `<p>${title}</p><p>经纬度：${coordinate[0].toString().substr(0, 8)},  ${coordinate[1].toString().substr(0, 8)}</p><p>${cont}</p>`
            var coordinates = feature.getGeometry().getCoordinates()
            _this.popupLayer.setPosition(coordinates)
          } else {
            if (feature.values_.name && feature.values_.name === 'warning') {
              _this.weatherQuery(coordinate)
            }
            const type = feature.getGeometry().getType()
            if (type === 'LineString') {
              _this.weatherQuery(coordinate)
            }
          }
        } else {
          // if (feature.values_.name && feature.values_.name === 'warning') {
          //   _this.weatherQuery(coordinate)
          // }
        }
      })
    },
    // 点击事件分类，触发给app传参
    typeListen (data) {
      if (data.monitorId) {
        this.monitonClick(data)
      } else {
        this.stationClick(data)
      }
    },
    getSouce () {
      console.log('getZoom', this.view.getZoom(), this.view.getMinZoom())
      let params = {projectId: 4}
      projectInfo(params).then(res => {
        this.projectSource = res.data.data
        this.pcProject()
      })
    }
  }
}
</script>
<style>
  .map {
    width: 100%;
    height: 100vh;
  }
  /* img {
    filter: grayscale(100%)!important;
    -webkit-filter: grayscale(100%)!important;
  } */
  .main {
    position: relative;
  }
  .loading {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.2);
  }
  .loading p {
    width: 100px;
    margin: 50% auto 0;
  }
  .ol-popup {
    position: absolute;
    background-color: white;
    box-shadow: 0 1px 4px rgba(0,0,0,0.2);
    padding: 6px 10px;
    border-radius: 10px;
    border: 1px solid #cccccc;
    bottom: 12px;
    left: -50px;
    min-width: 220px;
  }
  .ol-popup:after, .ol-popup:before {
    top: 100%;
    border: solid transparent;
    content: " ";
    height: 0;
    width: 0;
    position: absolute;
    pointer-events: none;
  }
  .ol-popup:after {
    border-top-color: white;
    border-width: 10px;
    left: 48px;
    margin-left: -10px;
  }
  .ol-popup:before {
    border-top-color: #cccccc;
    border-width: 11px;
    left: 48px;
    margin-left: -11px;
  }
  .ol-popup-closer {
    text-decoration: none;
    position: absolute;
    top: 2px;
    right: 8px;
  }
  #popup-content {
    font-size: 12px;
  }
  .ol-popup-closer:after {
    content: "✖";
    font-size: 0.6rem;
  }
  .ol-zoom {
    /*隐藏地图左上角的+-号*/
    display: none;
  }
</style>
